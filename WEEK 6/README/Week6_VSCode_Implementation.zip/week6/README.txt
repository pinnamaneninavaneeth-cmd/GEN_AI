WEEK 6 - GENERATIVE AI PROGRAMMING PRACTICAL
Release: v0.1

FILES
- main.py: Runs the baseline evaluation using Ollama.
- golden_set.json: Contains 30 questions, expected answers, keywords and sources.
- requirements.txt: Python dependency list.

SETUP (Windows / VS Code)
1. Install Python and Ollama.
2. Open PowerShell and download the model:
      ollama pull llama3.2
3. Open this folder in VS Code.
4. Open the VS Code terminal in this folder.
5. Install the Python dependency:
      python -m pip install -r requirements.txt
6. Make sure Ollama is running. If needed, open another terminal and run:
      ollama serve
7. Run the program:
      python main.py

OUTPUT
The program creates baseline_results.csv in this folder.
It evaluates each answer using keyword coverage. Scores >= 60% are marked PASS;
lower scores are marked REVIEW. Request failures are marked ERROR.

NOTE
The model must be downloaded before running the program. The first run may take
some time because all 30 questions are sent to the local model.
